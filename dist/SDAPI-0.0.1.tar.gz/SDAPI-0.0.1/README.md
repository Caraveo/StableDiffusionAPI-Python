# SDAPI
```
import sys
import os
import StableDiffusionAPI as sdapi

strapi = sdapi.StableDiffusionAPI("Moo", 1024, 1024, 1, "tractor.png")
```
