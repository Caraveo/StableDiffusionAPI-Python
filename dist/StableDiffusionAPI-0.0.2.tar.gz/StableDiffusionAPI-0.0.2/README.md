# SDAPI
```
import sys
import os
import StableDiffusionAPI as sdapi

strapi = sdapi.StableDiffusionAPI("Moo", 512, 512, 1, "moo.png")
```
# Requires API Key
[StableDiffusionAPI.com](https://stablediffusionapi.com/)
