import StableDiffusionAPI.key as key
def SetKey(key2):
    tkey = key2
    key.value = tkey
