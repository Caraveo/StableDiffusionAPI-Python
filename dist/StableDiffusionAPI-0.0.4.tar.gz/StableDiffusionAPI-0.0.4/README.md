# StableDiffuionAPI
```
import StableDiffusionAPI

StableDiffusionAPI.Key("StableDiffusionAPI_KEY")
StableDiffusionAPI.Text2Img("Tractor", 512, 512, "Tractor.png")
```
# Requires API Key
[StableDiffusionAPI.com](https://stablediffusionapi.com/)
