# StableDiffuionAPI
```
import StableDiffusionAPI

StableDiffusionAPI.Key("StableDiffusionAPI_KEY")
StableDiffusionAPI.Text2Img("Tractor", 512, 512, "Tractor.png")
```

# StableDiffuionAPI.Community
```
StableDiffusionAPI.Community as Community

Community.Text2Img("dreamlike", "Cat", "dreamlike-cat.png")
Community.Text2Img("midjourney", "Cat", "midjourney-cat.png")
```
# Requires API Key
[StableDiffusionAPI.com](https://stablediffusionapi.com/)
