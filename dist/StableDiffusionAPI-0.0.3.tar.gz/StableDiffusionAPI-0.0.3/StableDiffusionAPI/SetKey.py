import StableDiffusionAPI.key as key
def SetKey(key2):
    tkey = key2
    print("Key Set" , tkey)
    key.value = tkey
