class key:
    def __init__(self, key):
        self.key = key
    def value(self):
        return self.key

